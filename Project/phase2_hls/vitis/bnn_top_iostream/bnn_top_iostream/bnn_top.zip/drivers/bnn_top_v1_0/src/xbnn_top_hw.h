// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of l1_weights
//        bit 31~0 - l1_weights[31:0] (Read/Write)
// 0x14 : Data signal of l1_weights
//        bit 31~0 - l1_weights[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of l2_weights
//        bit 31~0 - l2_weights[31:0] (Read/Write)
// 0x20 : Data signal of l2_weights
//        bit 31~0 - l2_weights[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of l3_weights
//        bit 31~0 - l3_weights[31:0] (Read/Write)
// 0x2c : Data signal of l3_weights
//        bit 31~0 - l3_weights[63:32] (Read/Write)
// 0x30 : reserved
// 0x34 : Data signal of load_weights
//        bit 0  - load_weights[0] (Read/Write)
//        others - reserved
// 0x38 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XBNN_TOP_CONTROL_ADDR_AP_CTRL           0x00
#define XBNN_TOP_CONTROL_ADDR_GIE               0x04
#define XBNN_TOP_CONTROL_ADDR_IER               0x08
#define XBNN_TOP_CONTROL_ADDR_ISR               0x0c
#define XBNN_TOP_CONTROL_ADDR_L1_WEIGHTS_DATA   0x10
#define XBNN_TOP_CONTROL_BITS_L1_WEIGHTS_DATA   64
#define XBNN_TOP_CONTROL_ADDR_L2_WEIGHTS_DATA   0x1c
#define XBNN_TOP_CONTROL_BITS_L2_WEIGHTS_DATA   64
#define XBNN_TOP_CONTROL_ADDR_L3_WEIGHTS_DATA   0x28
#define XBNN_TOP_CONTROL_BITS_L3_WEIGHTS_DATA   64
#define XBNN_TOP_CONTROL_ADDR_LOAD_WEIGHTS_DATA 0x34
#define XBNN_TOP_CONTROL_BITS_LOAD_WEIGHTS_DATA 1

